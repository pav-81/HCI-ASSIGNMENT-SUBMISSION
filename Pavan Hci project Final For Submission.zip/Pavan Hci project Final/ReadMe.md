# Pass IT Driving School HCI Project

## Create and Use Virtual Environments to be able to use this code well
#### Ensure the following modules are imported in your code:

##### import tkinter as tk
##### from tkcalendar import DateEntry 
##### from PIL import Image, ImageTk

> **Note:** If you encounter errors related to these imports, ensure that the required packages are installed in your virtual environment. Errors can be easily see in the imports themselves have yellow underlines under them. Just know you have not imported it correctly. Also, if you run the code and see an error in the terminal, if its say Module PIL could not be found, or tkcalendar could not be found, just know you need to import it.

### Create a New Virtual Environment

`venv` (for Python 3) allows you to manage separate package installations for different projects. It creates a "virtual" isolated Python installation. When you switch projects, you can create a new virtual environment which is isolated from other virtual environments. You benefit from the virtual environment since packages can be installed confidently and will not interfere with another project's environment.

> **Tip:** It is recommended to use a virtual environment when working with third-party packages.

To create a virtual environment, go to your project's directory and run the following command. This will create a new virtual environment in a local folder named `.venv`:

**Unix/macOS**
python3 -m venv .venv

**Windows**
python -m venv .venv

`venv` will create a virtual Python installation in the `.venv` folder.

> **Note:** You should exclude your virtual environment directory from your version control system using `.gitignore` or similar.

### Activate a Virtual Environment

Before you can start installing or using packages in your virtual environment, you'll need to activate it. Activating a virtual environment will put the virtual environment-specific python and pip executables into your shell's PATH.

**Unix/macOS**
source .venv/bin/activate

**Windows**
.venv\Scripts\activate

To confirm the virtual environment is activated, check the location of your Python interpreter:

**Unix/macOS**
which python

**Windows**
where python

While the virtual environment is active, the above command will output a filepath that includes the `.venv` directory, such as:

**Unix/macOS**
.venv/bin/python

**Windows**
.venv\Scripts\python.exe

### Deactivate a Virtual Environment

If you want to switch projects or leave your virtual environment, deactivate the environment:

deactivate

> **Note:** Closing your shell will also deactivate the virtual environment. If you open a new shell window and want to use the virtual environment, reactivate it.

### Reactivate a Virtual Environment

To reactivate an existing virtual environment, follow the same instructions for activating a virtual environment. There's no need to create a new virtual environment.

## Prepare pip

`pip` is the reference Python package manager. It's used to install and update packages into a virtual environment.

**Unix/macOS**

The Python installers for macOS include `pip`. On Linux, you may have to install an additional package such as `python3-pip`. You can make sure that `pip` is up-to-date by running:

python3 -m pip install --upgrade pip
python3 -m pip --version

Afterwards, you should have the latest version of `pip` installed in your user site:

pip 23.3.1 from .../.venv/lib/python3.9/site-packages (python 3.9)

**Windows**

Ensure `pip` is up-to-date by running:

python -m pip install --upgrade pip
python -m pip --version

## Install Packages Using pip

When your virtual environment is activated, you can install packages. Use the `pip install` command to install packages.

### Install a Package

For example, let's install the Requests library from the Python Package Index (PyPI):

**Unix/macOS**
python3 -m pip install requests

**Windows**
pip install requests

`pip` should download `requests` and all of its dependencies and install them:

Collecting requests
  Using cached requests-2.18.4-py2.py3-none-any.whl
Collecting chardet<3.1.0,>=3.0.2 (from requests)
  Using cached chardet-3.0.4-py2.py3-none-any.whl
Collecting urllib3<1.23,>=1.21.1 (from requests)
  Using cached urllib3-1.22-py2.py3-none-any.whl
Collecting certifi>=2017.4.17 (from requests)
  Using cached certifi-2017.7.27.1-py2.py3-none-any.whl
Collecting idna<2.7,>=2.5 (from requests)
  Using cached idna-2.6-py2.py3-none-any.whl

## Project-Specific Instructions

This project requires the following additional packages to be installed before running:

- `tkinter`
- `tkcalendar`
- `Pillow`

Install them using the following command:

pip install tkcalendar Pillow

> **Note:** `tkinter` is usually included with Python, but if it is not, refer to your system's package manager or installation guide.

## Example Code


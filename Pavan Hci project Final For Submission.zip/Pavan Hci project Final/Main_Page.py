
import datetime
import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkFont
import sqlite3
import tkinter.simpledialog as sd
import time
import threading
from tkcalendar import DateEntry 
import random
from PIL import Image, ImageTk
import itertools
import os
import uuid  # For generating unique IDs for certificates
import re  # Import regular expressions for validation
import sys

# Determine if the script is running in a PyInstaller bundle
if getattr(sys, 'frozen', False):
    # Running in a PyInstaller bundle
    application_path = sys._MEIPASS
else:
    # Running in a normal Python environment
    application_path = os.path.dirname(os.path.abspath(__file__))

# Helper function to get the correct path
def get_path(relative_path):
    return os.path.join(application_path, relative_path)

class CourseSelectionDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Select a Course")
        self.geometry("300x200")
        self.grab_set()  # Make the dialog modal

        ttk.Label(self, text="Select a course:").pack(pady=10)
        
        self.course_combobox = ttk.Combobox(self, state="readonly")
        self.course_combobox.pack(pady=10)
        self.populate_courses()

        proceed_button = ttk.Button(self, text="Proceed", command=self.proceed)
        proceed_button.pack(pady=20)

    def populate_courses(self):
        courses = ["Introductory Course", "Theory Tests", "Pass Plus", "Practical Test"]
        self.course_combobox['values'] = courses
        if courses:
            self.course_combobox.current(0)

    def proceed(self):
        course_title = self.course_combobox.get()
        self.destroy()  # Close the dialog
        self.parent.add_student(course_title)  # Call the parent function to handle course selection


class EnrolledStudentsTab(ttk.Frame):
    def __init__(self, parent, db_students, db_instructors):
        super().__init__(parent)

        self.db_students = db_students
        self.db_instructors = db_instructors
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()
        self.populate_students()

    def create_widgets(self):
        # Search Frame
        search_frame = ttk.Frame(self)
        search_frame.pack(fill=tk.X, padx=10, pady=10)

        # Label for search entry
        search_label = ttk.Label(search_frame, text="Enter student details to search:")
        search_label.pack(side=tk.LEFT, padx=6)

        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=30)
        search_entry.pack(side=tk.LEFT, expand=True, padx=6)

        search_button = ttk.Button(search_frame, text="Search🔍", command=self.search_students)
        search_button.pack(side=tk.LEFT, padx=6)

        reset_button = ttk.Button(search_frame, text="🔄Reset Search", command=self.populate_students)
        reset_button.pack(side=tk.LEFT, padx=6)

        # Treeview for displaying students
        self.tree = ttk.Treeview(self, columns=("ID", "Name", "Email", "Phone", "Gender", "DOB", "Stream", "Tutor", "Session Date", "Session Time"), show="headings")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor=tk.W)
        self.tree.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        # Button Frame for Student Manipulation
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        # Creating a style for the add button
        add_button = ttk.Button(button_frame, text="Add Student➕", command=self.add_student)
        add_button.pack(side=tk.LEFT, padx=6)

        # Custom style for the delete button
        style = ttk.Style()
        style.configure('Danger.TButton', foreground='white', background='red')

        delete_button = ttk.Button(button_frame, text="Delete Student", style='Danger.TButton', command=self.delete_student)
        delete_button.pack(side=tk.LEFT, padx=6)

    def populate_students(self):
        # Clear existing data from the tree view first
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Use the correct database connection
        cursor = self.db_students.cursor()
        cursor.execute("SELECT * FROM SCHOOL_MANAGEMENT")
        rows = cursor.fetchall()

        # Insert items with tags for alternating colors
        for index, row in enumerate(rows):
            if index % 2 == 0:
                self.tree.insert('', 'end', values=row, tags=('evenrow',))
            else:
                self.tree.insert('', 'end', values=row, tags=('oddrow',))

        # Apply tag configurations if not already set
        self.tree.tag_configure('oddrow', background='#F5F5F5')  # Light gray
        self.tree.tag_configure('evenrow', background='#E0E0E0')  # Slightly darker gray

        cursor.close()

    def search_students(self):
        search_query = "SELECT * FROM SCHOOL_MANAGEMENT WHERE "
        conditions = []
        for col in ("NAME", "EMAIL", "PHONE_NO", "GENDER", "DOB", "STREAM", "TUTOR"):
            conditions.append(f"{col} LIKE '%{self.search_var.get()}%'")
        search_query += " OR ".join(conditions)
        cursor = self.db_students.cursor()
        cursor.execute(search_query)
        rows = cursor.fetchall()
        self.tree.delete(*self.tree.get_children())

        if not rows:
            messagebox.showinfo("Search Result", "No matching students found.")
            self.populate_students()  # Repopulate the list with all students
        else:
            for index, row in enumerate(rows):
                if index % 2 == 0:
                    self.tree.insert('', 'end', values=row, tags=('evenrow',))
                else:
                    self.tree.insert('', 'end', values=row, tags=('oddrow',))

            # Apply tag configurations if not already set
            self.tree.tag_configure('oddrow', background='#F5F5F5')  # Light gray
            self.tree.tag_configure('evenrow', background='#E0E0E0')  # Slightly darker gray

        cursor.close()


    def add_student(self, course_title=None):
        if course_title is None:
            CourseSelectionDialog(self)
        else:
            # Fetch tutors for the selected course
            cursor = self.db_instructors.cursor()
            cursor.execute("SELECT NAME FROM INSTRUCTORS WHERE SPECIALIZATION LIKE ?", (f'%{course_title}%',))
            tutors = cursor.fetchall()

            if not tutors:
                messagebox.showinfo("Unavailable", "No tutors available for this course at the moment. Please check back next week.")
            else:
                course = {'title': course_title}  # Assuming course needs to be a dictionary
                # Pass all required arguments to EnrollCourseForm
                EnrollCourseForm(self, self.refresh_students_display, course, self.db_students, self.db_instructors)

    def refresh_students_display(self):
        # This function should handle refreshing the students display
        self.populate_students()



    def delete_student(self):
        selected_item = self.tree.selection()
        if selected_item:
            # Fetch the student's details from the Treeview
            student_details = self.tree.item(selected_item, "values")
            student_id, name, email, phone, gender, dob, stream, tutor, session_date, session_time = student_details

            # Details message
            details_msg = f"Are you sure you want to delete the following student?\n\n" \
                        f"Name: {name}\n" \
                        f"Email: {email}\n" \
                        f"Phone: {phone}\n" \
                        f"Gender: {gender}\n" \
                        f"DOB: {dob}\n" \
                        f"Stream: {stream}\n" \
                        f"Tutor: {tutor}\n" \
                        f"Session Date: {session_date}\n" \
                        f"Session Time: {session_time}\n"

            # Create a dialog box
            if messagebox.askyesno("Confirm Deletion", details_msg, icon='warning'):
                # Proceed with deletion if user confirms
                # Use the correct database connection
                cursor = self.db_students.cursor()  # Change from self.db to self.db_students
                try:
                    cursor.execute("DELETE FROM SCHOOL_MANAGEMENT WHERE ID=?", (student_id,))
                    self.db_students.commit()
                    messagebox.showinfo("Success", "Student has been deleted successfully.")
                    self.populate_students()
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to delete student: {str(e)}")
                finally:
                    cursor.close()
            else:
                messagebox.showinfo("Cancelled", "Student deletion cancelled.")


class CertificationTab(ttk.Frame):
    def __init__(self, parent, db_students):
        super().__init__(parent)
        self.db_students = db_students
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        search_frame = ttk.Frame(self)
        search_frame.pack(expand=True)  # Center the search frame

        ttk.Label(search_frame, text="Enter Student Name, Email, or Phone Number:", font=('Arial', 12)).pack(pady=10)
        self.search_entry = ttk.Entry(search_frame, width=50, font=('Arial', 12))
        self.search_entry.pack(side=tk.LEFT, padx=10)

        search_button = ttk.Button(search_frame, text="Search Student🔍", command=self.search_student)
        search_button.pack(side=tk.LEFT, padx=10)

    def search_student(self):
        keyword = self.search_entry.get().strip()
        cursor = self.db_students.cursor()
        cursor.execute("SELECT * FROM SCHOOL_MANAGEMENT WHERE NAME LIKE ? OR EMAIL LIKE ? OR PHONE_NO LIKE ?", ('%' + keyword + '%', '%' + keyword + '%', '%' + keyword + '%'))
        student = cursor.fetchone()
        cursor.close()
        if student:
            self.display_certificate(student)
        else:
            messagebox.showinfo("Search Result", "No matching student found.")

    def display_certificate(self, student):
        details = tk.Toplevel(self)
        details.title("Certificate of Completion")
        details.geometry("800x1000")  # Set the size of the certificate window

        # Certificate main frame with border
        certificate_frame = ttk.Frame(details, padding="20 20 20 20", relief='solid', borderwidth=2)
        certificate_frame.pack(expand=True, fill=tk.BOTH, padx=50, pady=50)

        # Styling the certificate text area
        certificate_text = tk.Text(certificate_frame, wrap=tk.WORD, height=15, font=('Arial', 12), bg='ivory', borderwidth=0)
        certificate_text.pack(expand=True, fill=tk.BOTH)
        certificate_text.tag_configure('title', font=('Times New Roman', 28, 'bold'), foreground='navy', justify='center')
        certificate_text.tag_configure('body', font=('Times New Roman', 16), spacing3=5, justify='center')
        certificate_text.tag_configure('signature', font=('Cursive', 20), spacing3=30, justify='center')
        
        # Inserting content
        certificate_text.insert(tk.END, "Pass IT Driving School\n", 'title')
        certificate_text.insert(tk.END, "Certificate of Excellence\n\n", 'title')
        certificate_text.insert(tk.END, f"Presented to\n{student[1]}\n\n", 'body')
        certificate_text.insert(tk.END, f"For outstanding performance and dedication in completing the course:\n{student[6]}\n\n", 'body')
        certificate_text.insert(tk.END, f"Given this {datetime.date.today().strftime('%d')}th day of {datetime.date.today().strftime('%B')}, {datetime.date.today().year}\n\n", 'body')
        certificate_text.insert(tk.END, "This certificate is awarded in recognition of the exemplary commitment shown in achieving educational goals.\n\n", 'body')
        certificate_text.insert(tk.END, f"Tutor: {student[7]}\nSession Date: {student[8]}\nSession Time: {student[9]}\n\n", 'body')
        certificate_text.insert(tk.END, "Signature:\n", 'signature')
        certificate_text.insert(tk.END, "______________________\n", 'signature')
        certificate_text.insert(tk.END, "Pavan Patel\n", 'signature')
        certificate_text.insert(tk.END, "Manager, Pass IT Driving School", 'signature')
        certificate_text.config(state=tk.DISABLED)  # Make the text widget read-only




            # Apply styles locally with more vivid colors for better visibility and interaction
        style = ttk.Style(details)
        style.configure('LocalPrintButton.TButton', font=('Helvetica', 12, 'bold'), foreground='white', background='royal blue')
        style.configure('LocalCancelButton.TButton', font=('Helvetica', 12, 'bold'), foreground='white', background='crimson')

        # Button Frame for actions
        button_frame = ttk.Frame(details)
        button_frame.pack(fill=tk.X, pady=10)
        
        print_button = ttk.Button(button_frame, text="Print Certificate", command=lambda: self.print_certificate(details), style='LocalPrintButton.TButton')
        print_button.pack(side=tk.LEFT, padx=10, expand=True)
        
        cancel_button = ttk.Button(button_frame, text="Cancel", command=details.destroy, style='LocalCancelButton.TButton')
        cancel_button.pack(side=tk.LEFT, padx=10, expand=True)


    def print_certificate(self, details):
        messagebox.showinfo("Print Certificate", "Certificate printed successfully.")
        details.destroy()


class EnrollCourseForm(tk.Toplevel):
    def __init__(self, parent, update_callback, course, db_students, db_instructors):
        super().__init__(parent)
        self.update_callback = update_callback  # Store the callback
        self.course = course
        self.db_students = db_students
        self.db_instructors = db_instructors
        self.title(f"Enroll in {course['title']}")
        self.geometry("500x450")
        self.grab_set()
        self.resizable(width=False, height=False)
        self.create_form()



    def create_form(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TButton', font=('Helvetica', 10))
        style.configure('Red.TButton', font=('Helvetica', 10), background='#ff4c4c')
        
        fields = ['Name', 'Email', 'Phone Number', 'Gender', 'Date of Birth', 'Session Date', 'Session Time']
        self.entries = {}
        row = 0
        for field in fields:
            label = ttk.Label(self, text=field)
            label.grid(row=row, column=0, sticky='w', padx=20, pady=10)  # Increased padding

            if field == 'Gender':
                entry = ttk.Combobox(self, values=['Male', 'Female', 'Non-binary'], state="readonly")
            elif field in ['Date of Birth', 'Session Date']:
                entry = ttk.Entry(self, width=30)
                entry.insert(0, "DD-MM-YYYY")
                entry.bind("<FocusIn>", lambda event, e=entry: self.clear_placeholder(event, e))
                entry.bind("<FocusOut>", lambda event, e=entry, default="DD-MM-YYYY": self.add_placeholder(event, e, default))
            elif field == 'Session Time':
                entry = ttk.Combobox(self, values=['08:00', '11:00', '14:00', '17:00'], state="readonly")
            else:
                entry = ttk.Entry(self, width=30)

            entry.grid(row=row, column=1, padx=20, pady=10)  # Increased padding
            self.entries[field] = entry
            row += 1

        self.tutor_combobox = ttk.Combobox(self, width=30, state="readonly")
        self.populate_tutors()
        ttk.Label(self, text="Select Tutor:").grid(row=row, column=0, sticky='w', padx=20, pady=10)
        self.tutor_combobox.grid(row=row, column=1, padx=20, pady=10)
        row += 1

        button_frame = ttk.Frame(self)
        button_frame.grid(row=row, column=0, columnspan=2, pady=20)  # Increased padding

        enroll_button = ttk.Button(button_frame, text="Complete Enrollment", command=self.complete_enrollment, style='TButton')
        enroll_button.grid(row=0, column=0, padx=10, sticky='ew', ipadx=10)

        cancel_button = ttk.Button(button_frame, text="Cancel", command=self.destroy, style='Red.TButton')
        cancel_button.grid(row=0, column=1, padx=10, sticky='ew', ipadx=10)

        button_frame.columnconfigure(0, weight=1)
        button_frame.columnconfigure(1, weight=1)

    def clear_placeholder(self, event, entry):
        """Clear the placeholder text when the entry gets focus."""
        if entry.get() == "DD-MM-YYYY":
            entry.delete(0, tk.END)

    def add_placeholder(self, event, entry, default):
        """Reinsert placeholder text if the entry is empty when it loses focus."""
        if not entry.get():
            entry.insert(0, default)

    def validate_date(self, date_text):
        if date_text == "DD-MM-YYYY i.e 02-11-1970":
            messagebox.showerror("Invalid Date", "Please enter a valid date.")
            return False
        try:
            datetime.datetime.strptime(date_text, "%d-%m-%Y")
            return True
        except ValueError:
            messagebox.showerror("Invalid Date", "The date must be in DD-MM-YYYY format. i.e 02-11-1970")
            return False

    
    def populate_tutors(self):
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT NAME FROM INSTRUCTORS WHERE SPECIALIZATION LIKE ?", ('%' + self.course['title'] + '%',))
        tutors = cursor.fetchall()
        self.tutor_combobox['values'] = [t[0] for t in tutors]
        if tutors:
            self.tutor_combobox.current(0)
        else:
            messagebox.showinfo("Unavailable", "No tutors available for this course at the moment. Please check back later.")

    

    def complete_enrollment(self):
        student_info = {f: self.entries[f].get().strip() for f in self.entries}
        selected_tutor = self.tutor_combobox.get()

        # Validate input
        name_valid = re.match(r"^[A-Za-z ]{8,}$", student_info['Name']) and student_info['Name'].count(' ') <= 1
        phone_valid = student_info['Phone Number'].isdigit() and len(student_info['Phone Number']) >= 10
        email_valid = re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", student_info['Email'])
        dob_valid = self.validate_date(student_info['Date of Birth'])
        session_date_valid = self.validate_date(student_info['Session Date'])

        if not name_valid:
            messagebox.showerror("Validation Error", "Name must be at least 8 characters long and contain only alphabets and up to one space.")
        elif not phone_valid:
            messagebox.showerror("Validation Error", "Phone number must be numeric and at least 10 characters long.")
        elif not email_valid:
            messagebox.showerror("Validation Error", "Email must adhere to standard email format.")
        elif not selected_tutor:
            messagebox.showerror("Validation Error", "A tutor must be selected.")
        elif not dob_valid or not session_date_valid:
            # Errors for date formats will be shown by the validate_date function itself
            return
        elif not all(value for key, value in student_info.items() if key not in ['Session Time', 'Session Date']):
            messagebox.showerror("Enrollment Failed", "All fields are required, please fill them in!")
        else:
            session_date = student_info['Session Date']
            session_time = student_info['Session Time']
            try:
                self.db_students.execute(
                    "INSERT INTO SCHOOL_MANAGEMENT (NAME, EMAIL, PHONE_NO, GENDER, DOB, STREAM, TUTOR, SESSION_DATE, SESSION_TIME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (student_info['Name'], student_info['Email'], student_info['Phone Number'],
                    student_info['Gender'], student_info['Date of Birth'], self.course['title'], selected_tutor, session_date, session_time))
                self.db_students.commit()
                messagebox.showinfo("Enrollment Complete", f"{student_info['Name']} has been enrolled in {self.course['title']} with tutor {selected_tutor} on {session_date} at {session_time}")
                self.update_callback()  # Refresh the UI or data view
                self.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to enroll student: {str(e)}")

#adding tutor form
class AddTutorForm(tk.Toplevel):
    def __init__(self, parent, db_instructors, refresh_tutors_display 
                 , populate_tutor_selector):
        super().__init__(parent)
        self.db_instructors = db_instructors
        self.refresh_tutors_display = refresh_tutors_display
        self.populate_tutor_selector = populate_tutor_selector
        self.title("Add Tutor")
        self.geometry("350x430")
        self.resizable(width=False, height=False)
        self.create_form()

    
    def create_form(self):
        fields = ('Name', 'Contact', 'Charges', 'Mode', 'Specialization', 'Experience')
        self.entries = {}
        row = 0
        for field in fields:
            label = ttk.Label(self, text=field)
            label.grid(row=row, column=0, sticky='w', padx=10, pady=5)
            
            if field == 'Mode':
                # Mode using Combobox
                entry = ttk.Combobox(self, values=['Full Time', 'Part Time'], state="readonly")
                entry.current(0)  # Default to Full Time if desired
            elif field == 'Specialization':
                # Specialization using Combobox
                entry = ttk.Combobox(self, values=['Introductory Course', 'Theory Tests', 'Pass Plus', 'Practical Test'], state="readonly")
                entry.current(0)  # Default to the first specialization if desired
            elif field == 'Experience':
                # Experience using Combobox
                entry = ttk.Combobox(self, values=['Only Pros', 'Only Intermediate', 'Intermediate and above', 'Beginners', 'Mixed'], state="readonly")
                entry.current(0)  # Default to 'Only Pros' or any other appropriate default
            elif field == 'Charges':
                # Charges with validation
                entry = ttk.Entry(self, validate='key', validatecommand=(self.register(self.validate_float), '%P'))
            else:
                entry = ttk.Entry(self)
            
            entry.grid(row=row, column=1, padx=10, pady=5)
            self.entries[field] = entry
            row += 1

        button = ttk.Button(self, text="Add Tutor", command=self.submit_form)
        button.grid(row=row, columnspan=2, pady=20, padx=20, sticky='ew')
        
        # Cancel button with red style
        style = ttk.Style()
        style.configure('Danger.TButton', background='red', foreground='white')
        
        cancel_button = ttk.Button(self, text="Cancel", style='Danger.TButton', command=self.destroy)
        cancel_button.grid(row=row+1, columnspan=2, pady=10, padx=30, sticky='ew')


    def submit_form(self):
        tutor_info = {field: self.entries[field].get().strip() for field in self.entries}

        # Validate input
        name_valid = re.match(r"^[A-Za-z ]{8,}$", tutor_info['Name']) and tutor_info['Name'].count(' ') <= 1
        contact_valid = re.match(r"^\+?\d{10,}$", tutor_info['Contact'])  # Contact must be at least 10 digits, allow leading +
        try:
            charges_float = float(tutor_info['Charges'])
            charges_valid = charges_float > 0 and charges_float < 10000
        except ValueError:
            charges_valid = False  # Not a valid float, so validation fails

        if not name_valid:
            messagebox.showerror("Validation Error", "Name must be at least 8 characters long, contain only alphabets and up to one space.")
        elif not contact_valid:
            messagebox.showerror("Validation Error", "Contact must be numeric and at least 10 digits long.")
        elif not charges_valid:
            messagebox.showerror("Validation Error", "Charges must be a positive number and less than 10,000.")
        elif not all(tutor_info.values()):
            messagebox.showerror("Validation Error", "All fields must be filled out.")
        else:
            try:
                self.db_instructors.execute(
                    "INSERT INTO INSTRUCTORS (NAME, CONTACT, CHARGES, MODE, SPECIALIZATION, EXPERIENCE) VALUES (?, ?, ?, ?, ?, ?)",
                    (tutor_info['Name'], tutor_info['Contact'], charges_float,
                    tutor_info['Mode'], tutor_info['Specialization'], tutor_info['Experience']))
                self.db_instructors.commit()
                messagebox.showinfo("Success", "Tutor added successfully.")
                self.refresh_tutors_display()
                self.populate_tutor_selector()
                self.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add tutor: {str(e)}")



    def validate_float(self, value_if_allowed):
        if value_if_allowed:
            try:
                float(value_if_allowed)
                return True
            except ValueError:
                return False
        return True

    def validate_int(self, value_if_allowed):
        if value_if_allowed:
            try:
                int(value_if_allowed)
                return True
            except ValueError:
                return False
        return True



class RegisterDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Register Admin")
        self.geometry("700x350")
        self.resizable(width=False, height=False)
        self.db = parent.db_admins  # Use the database connection from the main application
       

        # Applying localized style
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('RegisterDialog.TLabel', font=('Helvetica', 10))
        style.configure('RegisterDialog.TEntry', font=('Helvetica', 10))
        style.configure('RegisterDialog.TButton', font=('Helvetica', 10, 'bold'), background='#afffbc')
        style.configure('RegisterDialog.Exit.TButton', font=('Helvetica', 10, 'bold'), background='#ffcccc')
        style.configure('RegisterDialog.Back.TButton', font=('Helvetica', 10, 'bold'), foreground='blue')  # A touch of red

        # Form fields for registration
        register_frame = ttk.Frame(self, padding=(20, 10))
        register_frame.grid(row=1, column=0, sticky='nsew')

        ttk.Label(register_frame, text="Username:", style='RegisterDialog.TLabel').grid(row=0, column=0, pady=10)
        self.username_entry = ttk.Entry(register_frame, width=25, style='RegisterDialog.TEntry')
        self.username_entry.grid(row=0, column=1, pady=10)

        ttk.Label(register_frame, text="Password:", style='RegisterDialog.TLabel').grid(row=1, column=0, pady=10)
        self.password_entry = ttk.Entry(register_frame, width=25, style='RegisterDialog.TEntry', show="*")
        self.password_entry.grid(row=1, column=1, pady=10)

        ttk.Button(register_frame, text="Register", command=self.register, style='RegisterDialog.TButton').grid(row=2, columnspan=2, pady=20)
        ttk.Button(register_frame, text="Already have an account? Login Here", command=self.back_register, style='RegisterDialog.Back.TButton').grid(row=3, columnspan=2, pady=20)

        # Image Carousel on the right
        self.image_label = ttk.Label(self)
        self.image_label.grid(row=1, column=2, sticky='nsew', padx=(10, 20), pady=(30, 0))
        self.images = self.load_images("img")  # This should point to your images directory
        self.image_cycle = itertools.cycle(self.images)
        self.update_image()

        self.focus_force()  # Focus the registration window

    

    def register(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if self.add_admin(username, password):
            messagebox.showinfo("Registration", "Registration successful!")
            self.destroy()  # Close registration dialog
            self.master.deiconify()  # Show the main window again
        else:
            messagebox.showerror("Registration Failed", "Username already exists!")
    def back_register(self):
        
        self.destroy()  # Close registration dialog
        self.master.deiconify()  # Show the main window again
        

    def add_admin(self, username, password):
        try:
            cursor = self.db.cursor()
            cursor.execute('INSERT INTO Admins (username, password) VALUES (?, ?)', (username, password))
            self.db.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def load_images(self, folder):
        image_files = [get_path(os.path.join(folder, file)) for file in os.listdir(get_path(folder)) if file.endswith(('png', 'jpg', 'jpeg'))]
        return [ImageTk.PhotoImage(Image.open(file).resize((300, 300), Image.Resampling.LANCZOS)) for file in image_files]

    def update_image(self):
        current_image = next(self.image_cycle)
        self.image_label.configure(image=current_image)
        self.image_label.image = current_image
        self.after(3000, self.update_image)  # Change image every 3000 milliseconds

class LoginDialog(tk.Toplevel):
    def __init__(self, parent, db_admins):
        super().__init__(parent)
        self.parent = parent  # Keep a reference to the parent
        self.title("Login")
        self.geometry("700x400")
        self.resizable(width=False, height=False)
        self.db_admins = db_admins    # Use the database connection from the main application
        self.login_successful = False  # Initialize this attribute


        # Applying localized style
        self.style = ttk.Style(self)
        self.style.theme_use('clam')
        self.style.configure('LoginDialog.TLabel', font=('Helvetica', 15, 'bold'))
        self.style.configure('LoginDialog.TEntry', font=('Helvetica', 10))
        self.style.configure('LoginDialog.TButton', font=('Helvetica', 10, 'bold'), background='#afffbc')
        self.style.configure('LoginDialog.Exit.TButton', font=('Helvetica', 10, 'bold'), background='#ff6666')
        self.style.configure('LoginDialog.Register.TButton', font=('Helvetica', 10), foreground='blue')

        # Welcome message
        welcome_label = ttk.Label(self, text="Welcome to Pass IT Driving School\nPlease login to continue", style='LoginDialog.TLabel')
        welcome_label.grid(row=0, column=0, columnspan=3, pady=20)

        # Creating form fields on the left
        login_frame = ttk.Frame(self, padding=(20, 10))
        login_frame.grid(row=1, column=0, sticky='nsew')

        ttk.Label(login_frame, text="Username:", style='LoginDialog.TLabel').grid(row=0, column=0, pady=10)
        self.username_entry = ttk.Entry(login_frame, width=25, style='LoginDialog.TEntry')
        self.username_entry.grid(row=0, column=1, pady=10)

        ttk.Label(login_frame, text="Password:", style='LoginDialog.TLabel').grid(row=1, column=0, pady=10)
        self.password_entry = ttk.Entry(login_frame, width=25, style='LoginDialog.TEntry', show="*")
        self.password_entry.grid(row=1, column=1, pady=10)

        ttk.Button(login_frame, text="Login", command=self.login, style='LoginDialog.TButton').grid(row=2, columnspan=2, pady=20)
        ttk.Button(login_frame, text="Exit", command=self.destroy, style='LoginDialog.Exit.TButton').grid(row=3, columnspan=2, pady=5)
        ttk.Button(login_frame, text="Not registered? Register here", command=self.open_registration, style='LoginDialog.Register.TButton').grid(row=4, columnspan=2, pady=10)

        # Image Carousel on the right
        self.image_label = ttk.Label(self)
        self.image_label.grid(row=1, column=2, sticky='nsew', padx=(0, 10))
        self.images = self.load_images("img")
        self.image_cycle = itertools.cycle(self.images)
        self.update_image()

    def open_registration(self):
        self.withdraw()  # Hide the login dialog temporarily
        reg_dialog = RegisterDialog(self)
        reg_dialog.grab_set()  # Make the register dialog modal
        self.wait_window(reg_dialog)  # Wait for the register dialog to close before showing login again
        self.deiconify()  # Re-show the login dialog

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if self.check_credentials(username, password):
            self.login_successful = True  # Set the flag to True on successful login
            self.event_generate("<<LoginSuccess>>", when="tail")
            self.destroy()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")


    def check_credentials(self, username, password):
        """Check the login credentials against the database, ignoring case for the username."""
        cursor = self.db_admins.cursor()
        # Convert the input username to lowercase and also compare with lowercase username in the database
        cursor.execute('SELECT * FROM Admins WHERE LOWER(username)=LOWER(?) AND password=?', (username, password))
        return cursor.fetchone() is not None


    def load_images(self, folder):
        image_files = [get_path(os.path.join(folder, file)) for file in os.listdir(get_path(folder)) if file.endswith(('png', 'jpg', 'jpeg'))]
        return [ImageTk.PhotoImage(Image.open(file).resize((300, 300), Image.Resampling.LANCZOS)) for file in image_files]


    def update_image(self):
        current_image = next(self.image_cycle)
        self.image_label.configure(image=current_image)
        self.image_label.image = current_image  # keep a reference!
        self.after(3000, self.update_image)  # change image every 3000 milliseconds

    def login_success(self):
        self.event_generate("<<LoginSuccess>>", when="tail")
        self.destroy()

class PassITApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Main Application")
        self.geometry("1100x600")  # Set an initial size for the main window
        self.resizable(False, False)  # Prevent the window from being resizable
        # Set up color variables
        self.primary_color = '#cfffe5'  # A soft green
        self.secondary_color = '#afffbc'  # A lighter soft green
        # Font configurations
        self.headlabelfont = ("Noto Sans CJK TC", 15, 'bold')
        self.labelfont = ('Garamond', 14)
        self.entryfont = ('Garamond', 12)
        self.configure(background=self.primary_color)

        self.create_databases()

        self.withdraw()  # Hide main window initially
        login = LoginDialog(self, self.db_admins)
        self.wait_window(login)  # Wait until the login window is closed

        if login.login_successful:  # Check the login flag
            self.deiconify()  # Show the main window if login was successful
            self.create_ui()  # Initialize the main UI components if the login is successful
        else:
            self.destroy()  # Close the application if login failed

    def create_admins_table(self):
        cursor = self.db_admins.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Admins (
                username TEXT PRIMARY KEY,
                password TEXT
            )
        ''')
        self.db_admins.commit()

        

    def create_databases(self):
        # Connect to or create necessary databases
        self.db_students = sqlite3.connect(get_path('SchoolManagement.db'))
        self.db_instructors = sqlite3.connect(get_path('Instructors.db'))
        self.db_timetable = sqlite3.connect(get_path('Timetable.db'))  # New database connection for timetable
        self.db_admins = sqlite3.connect(get_path('Admins.db'))  # Database for Admins

        # Create tables if they don't exist
        self.create_students_table()
        self.create_instructors_table()
        self.create_timetable_table()  # New method to create the timetable table
        self.create_admins_table()  # New method to create the admins table


    def create_students_table(self):
        cursor = self.db_students.cursor()
        # Adjust the SQL statement to include SESSION_DATE and SESSION_TIME
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS SCHOOL_MANAGEMENT (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                NAME TEXT,
                EMAIL TEXT,
                PHONE_NO TEXT,
                GENDER TEXT,
                DOB TEXT,
                STREAM TEXT,
                TUTOR TEXT,
                SESSION_DATE TEXT,  
                SESSION_TIME TEXT
            )
        ''')
        self.db_students.commit()

    def create_timetable_table(self):
        cursor = self.db_timetable.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS TIMETABLE (
                ID TEXT PRIMARY KEY,
                TUTOR_ID INTEGER,
                STUDENT_ID INTEGER,
                TUTOR_NAME TEXT,
                STUDENT_NAME TEXT,
                LESSON_TYPE TEXT,
                SESSION_DATE TEXT,
                SESSION_TIME TEXT,
                SUCCESS_RATE INTEGER,
                LOCATION TEXT
            )
        ''')
        self.db_timetable.commit()


    def create_instructors_table(self):
        cursor = self.db_instructors.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS INSTRUCTORS (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                NAME TEXT,
                CONTACT TEXT,
                CHARGES REAL,
                MODE TEXT,
                SPECIALIZATION TEXT,
                EXPERIENCE TEXT
            )
        ''')
        self.db_instructors.commit()


    def create_ui(self):
        tab_control = ttk.Notebook(self)
        tab_control.pack(expand=1, fill="both", padx=10, pady=10)

        # Style configuration for the entire UI
        style = ttk.Style(self)
        style.theme_use('clam')  # Using a theme that supports background color better

        # Configuring frame style
        style.configure('TFrame', background=self.primary_color)
        style.configure('TLabel', background=self.primary_color, font=self.labelfont)
        style.configure('TButton', background=self.secondary_color, font=self.labelfont)

        # Configuring tab style
        style.configure('TNotebook', background=self.primary_color, borderwidth=0)
        style.configure('TNotebook.Tab', background=self.secondary_color, padding=[5, 2], foreground='black')
        style.map('TNotebook.Tab',
                  background=[('selected', self.primary_color), ('active', self.secondary_color)],
                  foreground=[('selected', 'black')])

        # Create tabs and widgets with explicit backgrounds
        home_tab = ttk.Frame(tab_control, style='TFrame')
        tab_control.add(home_tab, text='Home🏠')
        self.create_home_ui(home_tab)

        
        # Courses Tab
        courses_tab = ttk.Frame(tab_control)
        tab_control.add(courses_tab, text='Courses📚')
        self.create_courses_ui(courses_tab)

        # Tutors Tab
        tutors_tab = ttk.Frame(tab_control)
        tab_control.add(tutors_tab, text='Tutors🧑‍🏫')
        self.create_tutors_ui(tutors_tab) 

        # In PassITApp or where you manage tabs
        self.enrolled_students_tab = EnrolledStudentsTab(tab_control, self.db_students, self.db_instructors)
        tab_control.add(self.enrolled_students_tab, text='Enrolled Students👩‍🎓')



        

        # About Tab
        about_tab = ttk.Frame(tab_control)
        tab_control.add(about_tab, text='About us🗲')
        self.create_about_ui(about_tab)

        # Timetable Tab
        timetable_tab = ttk.Frame(tab_control, style='TFrame')
        tab_control.add(timetable_tab, text='Timetable📆')
        self.create_timetable_ui(timetable_tab)

        # Prices Tab
        prices_tab = ttk.Frame(tab_control)
        tab_control.add(prices_tab, text='Prices💵')
        self.create_prices_ui(prices_tab)  

        # Certification Tab
        certification_tab = CertificationTab(tab_control, self.db_students)
        tab_control.add(certification_tab, text='Certification🎓')
        # Add Exit Tab
        exit_tab = ttk.Frame(tab_control, style='TFrame')
        tab_control.add(exit_tab, text='Exit🚪')
        self.create_exit_ui(exit_tab)

        tab_control.pack(expand=1, fill="both")

        # Bind tab switching event
        tab_control.bind("<<NotebookTabChanged>>", self.on_tab_change)

    def create_exit_ui(self, exit_tab):
        # Create a button in the exit_tab that when clicked will call self.quit_app
        # Display admin name
        login_info_label = ttk.Label(exit_tab, text=f"Hitting the Exit Application button will close the application so make sure you have saved all your data.")
        login_info_label.pack(pady=(20, 10), padx=20)

        # Create a button in the exit_tab that when clicked will call self.quit_app
        exit_button = ttk.Button(exit_tab, text="Exit Application", command=self.quit_app)
        exit_button.pack(pady=(10, 20), padx=20)

    def quit_app(self):
        # Method to close the application
        self.quit()  # Close the main Tkinter loop
        self.destroy()  # Destroy all widgets


        
    def create_home_ui(self, home_tab):
        # School banner at the top right
        banner_frame = ttk.Frame(home_tab)
        banner_frame.grid(row=0, column=1, sticky='ne', padx=10, pady=10)
        banner_label = ttk.Label(banner_frame, text="Pass IT Driving School", font=('Helvetica', 24, 'bold'), background='white')
        banner_label.pack()

        # Image carousel setup on the left
        image_frame = ttk.Frame(home_tab)
        image_frame.grid(row=1, column=0, sticky='nw', padx=10, pady=10)
        self.images = self.load_images('home_ui_images')
        self.image_cycle = itertools.cycle(self.images)
        self.image_label = ttk.Label(image_frame, borderwidth=0, relief=tk.FLAT)
        self.image_label.pack(fill=tk.BOTH, expand=True)
        self.update_image()

        # Welcome and quick stats display on the right
        stats_frame = ttk.Frame(home_tab)
        stats_frame.grid(row=1, column=1, sticky='ne', padx=10, pady=10)
        welcome_label = ttk.Label(stats_frame, text="Quick Stats", font=('Helvetica', 18, 'bold'))
        welcome_label.pack()

        num_students = self.fetch_count(self.db_students, 'SCHOOL_MANAGEMENT')
        num_instructors = self.fetch_count(self.db_instructors, 'INSTRUCTORS')
        num_courses = 4  # Example static data

        for name, value in [("Students", num_students), ("Instructors", num_instructors), ("Courses", num_courses)]:
            ttk.Label(stats_frame, text=f"{name}: {value}", font=('Arial', 12, 'bold')).pack()

        # List of courses offered
        courses_frame = ttk.Frame(stats_frame)
        courses_frame.pack(pady=10)
        ttk.Label(courses_frame, text="Courses Offered:", font=('Arial', 14, 'bold')).pack()
        courses_list = ["Defensive Driving", "Advanced Techniques", "Beginner's Course", "Commercial Driving"]
        for course in courses_list:
            ttk.Label(courses_frame, text=f"• {course}", font=('Arial', 12)).pack(anchor='w')

        # Interactive elements for more information and updates
        action_frame = ttk.Frame(home_tab)
        action_frame.grid(row=2, column=1, sticky='ne', padx=10, pady=10)
        ttk.Button(action_frame, text="More Info", command=self.show_more_info).pack(side=tk.LEFT, padx=10)
        ttk.Button(action_frame, text="Check Updates", command=self.show_recent_updates).pack(side=tk.LEFT, padx=10)

    def show_recent_updates(self):
        updates = [
            f"We now have {self.fetch_count(self.db_students, 'SCHOOL_MANAGEMENT')} students enrolled!",
            f"New Tutor Hired: {self.random_tutor()}",
            f"Opened a new location: {self.random_location()}"
        ]
        random_update = random.choice(updates)
        messagebox.showinfo("Recent Updates", random_update)

    def random_tutor(self):
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT NAME FROM INSTRUCTORS ORDER BY RANDOM() LIMIT 1")
        result = cursor.fetchone()
        return result[0] if result else "No tutors available."

    def random_location(self):
        locations = ['Downtown Campus', 'Uptown Campus', 'East Side Campus']
        return random.choice(locations)

    def show_more_info(self):
        messagebox.showinfo("More Info", "Explore our diverse courses and experienced instructors!")

    def load_images(self, folder):
        image_files = [get_path(os.path.join(folder, file)) for file in os.listdir(get_path(folder)) if file.endswith(('png', 'jpg', 'jpeg'))]
        return [ImageTk.PhotoImage(Image.open(file).resize((300, 300), Image.Resampling.LANCZOS)) for file in image_files]


    def update_image(self):
        current_image = next(self.image_cycle)
        self.image_label.configure(image=current_image)
        self.image_label.image = current_image
        self.after(3000, self.update_image)

    def fetch_count(self, db, table, distinct=False, column='*'):
        cursor = db.cursor()
        if distinct:
            cursor.execute(f"SELECT COUNT(DISTINCT {column}) FROM {table}")
        else:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
        return cursor.fetchone()[0]

    



    def show_recent_updates(self):
        updates = [
            f"We now have {self.fetch_count(self.db_students, 'SCHOOL_MANAGEMENT')} students enrolled!",
            f"New Tutor Hired: {self.random_tutor()}",
            f"Opened a new location: {self.random_location()}"
        ]
        random_update = random.choice(updates)
        messagebox.showinfo("Recent Updates", random_update)

    def random_tutor(self):
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT NAME FROM INSTRUCTORS ORDER BY RANDOM() LIMIT 1")
        result = cursor.fetchone()
        return result[0] if result else "No tutors available."

    def random_location(self):
        locations = ['Downtown Campus', 'Uptown Campus', 'East Side Campus']
        return random.choice(locations)

    def show_more_info(self):
        messagebox.showinfo("More Info", "Explore our diverse courses and experienced instructors!")

    def load_images(self, folder):
        """Loads images from the specified folder for the carousel."""
        image_files = [os.path.join(folder, file) for file in os.listdir(folder) if file.endswith(('png', 'jpg', 'jpeg'))]
        return [ImageTk.PhotoImage(Image.open(file).resize((300, 300), Image.ANTIALIAS)) for file in image_files]

    def update_image(self):
        """Updates the image displayed in the image label."""
        current_image = next(self.image_cycle)
        self.image_label.configure(image=current_image)
        self.image_label.image = current_image  # Keep a reference!
        self.after(3000, self.update_image)  # Change image every 3000 milliseconds

    def fetch_count(self, db, table, distinct=False, column='*'):
        cursor = db.cursor()
        if distinct:
            cursor.execute(f"SELECT COUNT(DISTINCT {column}) FROM {table}")
        else:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
        return cursor.fetchone()[0]
  



    def on_tab_change(self, event):
        current_tab = event.widget.tab(event.widget.select(), "text")
        if current_tab == 'Home':
            self.configure(bg=self.primary_color)
        elif current_tab == 'Students':
            self.configure(bg=self.secondary_color)
        elif current_tab == 'Courses':
            self.configure(bg='LightGreen')
        elif current_tab == 'About':
            self.configure(bg='LightBlue')
        elif current_tab == 'Prices':
            self.configure(bg='LightYellow')
    

    def add_tutor(self):
        # Open the AddTutorForm and pass the refresh_tutors_display method
        AddTutorForm(self, self.db_instructors, self.display_tutors, self.populate_tutor_selector)

    def create_courses_ui(self, courses_tab):
        top_frame = ttk.Frame(courses_tab)
        top_frame.pack(fill=tk.X)
        course_label = ttk.Label(top_frame, text="Available Driving Courses", font=('Noto Sans CJK TC', 18, 'bold'))
        course_label.pack(side=tk.TOP, pady=20)

        # Three columns for courses
        column_frames = [ttk.Frame(courses_tab) for _ in range(3)]
        for frame in column_frames:
            frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10)

        courses = [
            {"title": "Introductory Course", "description": "Ideal for beginners to learn vehicle controls and basic road safety.", "requirements": "No prior experience needed.", "price": "$100", "sessions": "5"},
            {"title": "Theory Tests", "description": "Enhances driving skills for handling more complex driving conditions.", "requirements": "Basic driving proficiency.", "price": "$200", "sessions": "10"},
            {"title": "Pro Driving Exams", "description": "Learn to handle adverse weather conditions safely.", "requirements": "Intermediate driving skills.", "price": "$250", "sessions": "7"},
            {"title": "Practical Test", "description": "Focused sessions to prepare for the driving test, covering test routes and maneuvers.", "requirements": "Pre-test assessment completion.", "price": "$150", "sessions": "6"},
            {"title": "Pass Plus", "description": "Advanced course for those who have passed their driving test and want to improve their skills.", "requirements": "Must have passed basic course.", "price": "$300", "sessions": "8"}
            
        ]

        # Distribute courses into columns, making sure to wrap around every three courses
        for idx, course in enumerate(courses):
            frame = ttk.Frame(column_frames[idx % 3], borderwidth=1, relief="solid", padding=10)
            frame.pack(pady=10, fill=tk.X, expand=False)
            ttk.Label(frame, text=course["title"], font=('Arial', 14, 'bold')).pack(anchor='nw')
            ttk.Label(frame, text=course["description"], wraplength=650).pack(anchor='nw')
            ttk.Label(frame, text=f"Requirements: {course['requirements']}").pack(anchor='nw')
            ttk.Label(frame, text=f"Price: {course['price']}, Sessions: {course['sessions']}").pack(anchor='nw')
            ttk.Button(frame, text="Enroll", command=lambda c=course: self.enroll_course(c)).pack(pady=10)




    def enroll_course(self, course):
        # First, check if there are any tutors available for the given course
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT NAME FROM INSTRUCTORS WHERE SPECIALIZATION LIKE ?", ('%' + course['title'] + '%',))
        tutors = cursor.fetchall()
        
        if not tutors:
            # No tutors available for the course, display a message
            messagebox.showinfo("Unavailable", "No tutors available for this course at the moment. Please check back next week.")
        else:
            # Assuming `enrolled_students_tab` is accessible from here or passed to this class at initialization
            EnrollCourseForm(self, self.enrolled_students_tab.refresh_students_display, course, self.db_students, self.db_instructors).grab_set()


    def create_tutors_ui(self, tutors_tab):
    # Creating UI elements for the Tutors tab
        search_frame = ttk.Frame(tutors_tab)
        search_frame.pack(pady=20)

        # Label for search entry
        search_label = ttk.Label(search_frame, text="Enter search details:")
        search_label.grid(row=0, column=0, padx=5, sticky='e')

        # Search entry without placeholder
        self.search_entry = ttk.Entry(search_frame, width=30)
        self.search_entry.grid(row=0, column=1, padx=5)

        # Search button
        search_button = ttk.Button(search_frame, text="🔍Search", command=self.search_tutors)
        search_button.grid(row=0, column=2, padx=5)

        # Reset button to clear search and refresh the list
        reset_button = ttk.Button(search_frame, text="🔄Reset Search", command=self.reset_search)
        reset_button.grid(row=0, column=3, padx=5)

        # Add tutor button
        add_tutor_button = ttk.Button(search_frame, text="Add Tutor➕", command=self.add_tutor)
        add_tutor_button.grid(row=0, column=4, padx=5)

        # Label displaying the number of tutors
        self.num_tutors_label = ttk.Label(tutors_tab, text="Number of Tutors: 0", font=('Arial', 12))
        self.num_tutors_label.pack(pady=10)

        # Treeview for displaying tutors
        self.tutors_tree = ttk.Treeview(tutors_tab, columns=('ID', 'Name', 'Contact', 'Charges', 'Mode', 'Specialization', 'Experience'), show='headings')
        self.tutors_tree.pack(pady=20, fill=tk.BOTH, expand=True)

        # Define column headings and configure them
        for col in ('ID', 'Name', 'Contact', 'Charges', 'Mode', 'Specialization', 'Experience'):
            self.tutors_tree.heading(col, text=col)
            self.tutors_tree.column(col, width=tkFont.Font().measure(col.title()), anchor='w')

        # Initial display of tutors
        self.display_tutors()

        # Bind Treeview select event to display tutor information
        self.tutors_tree.bind("<<TreeviewSelect>>", self.on_tutor_selected)
    def reset_search(self):
        """Clears the search bar and resets the tutor list."""
        self.search_entry.delete(0, tk.END)
        self.search_entry.insert(0, "Enter tutor's name or contact")
        self.display_tutors()  # Refresh and display all tutors again


    def on_entry_click(self, event):
        """Clear the placeholder text when the entry gets focus."""
        if self.search_entry.get() == "Enter tutor's name or contact":
            self.search_entry.delete(0, tk.END)

    def on_focusout(self, event):
        """Reinsert placeholder text if the entry is empty when it loses focus."""
        if not self.search_entry.get():
            self.search_entry.insert(0, "Enter tutor's name or contact")

    def display_tutors(self):
        # Clear existing data
        for row in self.tutors_tree.get_children():
            self.tutors_tree.delete(row)
        
        # Define tag configurations for alternating colors
        self.tutors_tree.tag_configure('oddrow', background='#F5F5F5')  # Light gray
        self.tutors_tree.tag_configure('evenrow', background='#E0E0E0')  # Slightly darker gray

        # Fetch and display new data
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT * FROM INSTRUCTORS")
        tutors = cursor.fetchall()
        
        # Insert items with tags for alternating colors
        for index, tutor in enumerate(tutors):
            if index % 2 == 0:
                self.tutors_tree.insert('', 'end', values=tutor, tags=('evenrow',))
            else:
                self.tutors_tree.insert('', 'end', values=tutor, tags=('oddrow',))

        # Update number of tutors label
        num_tutors = len(tutors)
        self.num_tutors_label.config(text=f"Number of Tutors: {num_tutors}")





        
    def delete_tutor(self, tutor_id):
        # Confirm deletion
        confirm = messagebox.askyesno("Confirm Deletion", "Are you sure you want to delete this tutor?")
        if not confirm:
            return

        # Delete tutor from database
        try:
            self.db_instructors.execute("DELETE FROM INSTRUCTORS WHERE ID=?", (tutor_id,))
            self.db_instructors.commit()
            messagebox.showinfo("Success", "Tutor deleted successfully.")
            self.display_tutors()  # Refresh displayed tutors
            self.populate_tutor_selector
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete tutor: {str(e)}")


    def search_tutors(self):
        # Get search keyword
        keyword = self.search_entry.get().strip()

        # Clear existing data
        for row in self.tutors_tree.get_children():
            self.tutors_tree.delete(row)

        # Retrieve matching tutor records from database and display
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT * FROM INSTRUCTORS WHERE NAME LIKE ? OR CONTACT LIKE ? OR CHARGES LIKE ?", ('%' + keyword + '%', '%' + keyword + '%', '%' + keyword + '%'))
        tutors = cursor.fetchall()

        if not tutors:
            messagebox.showinfo("Search Result", "No tutors match the entered keyword")
            self.display_tutors()  # Optionally reset the list if no match found
        else:
            # Use tags to alternate row colors
            for index, tutor in enumerate(tutors):
                if index % 2 == 0:
                    self.tutors_tree.insert('', 'end', values=tutor, tags=('evenrow',))
                else:
                    self.tutors_tree.insert('', 'end', values=tutor, tags=('oddrow',))

            num_tutors = len(tutors)
            self.num_tutors_label.config(text=f"Number of Tutors: {num_tutors}")

            # Apply tag configurations if not already set
            self.tutors_tree.tag_configure('oddrow', background='#F5F5F5')  # Light gray
            self.tutors_tree.tag_configure('evenrow', background='#E0E0E0')  # Slightly darker gray



    def display_selected_tutor_info(self, tutor_info=None):
        if tutor_info is None:
            selected_item = self.tutors_tree.selection()
            if not selected_item:
                messagebox.showerror("Error", "Please select a tutor.")
                return

            tutor_info = self.tutors_tree.item(selected_item)['values']

        column_names = self.tutors_tree["columns"]

        # Display tutor info in a pop-up window
        popup = tk.Toplevel(self)
        popup.title("Tutor Information")
        popup.geometry("300x400")

        # Display tutor info in labels
        for i in range(len(column_names)):
            ttk.Label(popup, text=f"{column_names[i]}: {tutor_info[i]}").pack()

        # Add delete and cancel buttons
        delete_button = ttk.Button(popup, text="Delete", command=lambda: self.delete_tutor(tutor_info[0]))
        delete_button.pack(pady=10)
        cancel_button = ttk.Button(popup, text="Cancel", command=popup.destroy)
        cancel_button.pack(pady=5)





    def on_tutor_selected(self, event):
        # Get selected tutor's information
        selected_item = self.tutors_tree.selection()
        if selected_item:
            tutor_id = self.tutors_tree.item(selected_item)['values'][0]
            cursor = self.db_instructors.cursor()
            cursor.execute("SELECT * FROM INSTRUCTORS WHERE ID=?", (tutor_id,))
            tutor_info = cursor.fetchone()
            if tutor_info:
                self.display_selected_tutor_info(tutor_info)   
    

    def create_timetable_ui(self, timetable_tab):
        # Set up the frame and widgets for the timetable
        header_frame = ttk.Frame(timetable_tab)
        header_frame.pack(fill=tk.X, padx=10, pady=5)

        # Label for the header
        header_label = ttk.Label(header_frame, text="Tutor Schedules", font=("Helvetica", 16))
        header_label.pack(side=tk.LEFT, padx=10, pady=10)

        # Combobox for selecting tutors
        self.tutor_selector = ttk.Combobox(header_frame, width=50, state="readonly")
        self.tutor_selector.pack(side=tk.LEFT, padx=10)
        self.tutor_selector.bind("<<ComboboxSelected>>", self.refresh_timetable)

        # Populate the combobox with tutor names from the INSTRUCTORS table
        self.populate_tutor_selector()

        # Treeview for displaying the timetable
        self.timetable_tree = ttk.Treeview(timetable_tab, columns=('Session Time', 'Lesson Type', 'Student', 'Student Contact', 'Tutor Name', 'Session Date'), show='headings')
        self.timetable_tree.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        # Define the headings
        for col in ('Session Time', 'Lesson Type', 'Student', 'Student Contact', 'Tutor Name', 'Session Date'):
            self.timetable_tree.heading(col, text=col)
            self.timetable_tree.column(col, width=150, anchor='w')

    def populate_tutor_selector(self):
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT NAME FROM INSTRUCTORS")
        tutors = cursor.fetchall()
        self.tutor_selector['values'] = [tutor[0] for tutor in tutors]
        cursor.close()

    def refresh_timetable(self, event=None):
        selected_tutor = self.tutor_selector.get()

        # Clear the existing entries in the Treeview
        for i in self.timetable_tree.get_children():
            self.timetable_tree.delete(i)

        # Define tag configurations for alternating colors
        self.timetable_tree.tag_configure('oddrow', background='#FAFAFA')
        self.timetable_tree.tag_configure('evenrow', background='#ECECEC')

        # Fetch the data for the selected tutor from the database
        cursor = self.db_students.cursor()
        query = '''
            SELECT SESSION_TIME, STREAM AS 'Lesson Type', NAME AS 'Student', PHONE_NO AS 'Student Contact', TUTOR AS 'Tutor Name', SESSION_DATE
            FROM SCHOOL_MANAGEMENT
            WHERE TUTOR = ?
        '''
        cursor.execute(query, (selected_tutor,))
        rows = cursor.fetchall()
        
        # Insert items with tags for alternating colors
        for index, row in enumerate(rows):
            if index % 2 == 0:
                self.timetable_tree.insert('', 'end', values=row, tags=('evenrow',))
            else:
                self.timetable_tree.insert('', 'end', values=row, tags=('oddrow',))


        cursor.close()
    def refresh_tutors_display(self):
        """Updates the tutor selector ComboBox."""
        try:
            cursor = self.db_instructors.cursor()
            cursor.execute("SELECT NAME FROM INSTRUCTORS")
            tutors = cursor.fetchall()
            self.tutor_selector['values'] = [tutor[0] for tutor in tutors]
            if tutors:
                self.tutor_selector.current(0)
            cursor.close()
        except Exception as e:
            print(f"Failed to refresh tutors: {str(e)}")
    
    def create_prices_ui(self, prices_tab):
        # Frame for the Treeview
        tree_frame = ttk.Frame(prices_tab)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)

        # Define the Treeview with columns
        self.prices_tree = ttk.Treeview(tree_frame, columns=("Name", "Specialization", "Mode", "For", "Price"), show="headings")
        self.prices_tree.pack(fill=tk.BOTH, expand=True)

        # Define headings
        self.prices_tree.heading("Name", text="Tutor's Name")
        self.prices_tree.heading("Specialization", text="Specialization")
        self.prices_tree.heading("Mode", text="Mode")
        self.prices_tree.heading("For", text="For")
        self.prices_tree.heading("Price", text="Price")

        # Define column widths
        self.prices_tree.column("Name", anchor="w", width=120)
        self.prices_tree.column("Specialization", anchor="w", width=150)
        self.prices_tree.column("Mode", anchor="w", width=100)
        self.prices_tree.column("For", anchor="w", width=150)
        self.prices_tree.column("Price", anchor="w", width=80)

        # Define tag styles for alternating colors
        self.prices_tree.tag_configure('oddrow', background='#E8E8E8')
        self.prices_tree.tag_configure('evenrow', background='#DFDFDF')

        # Button to refresh the data
        refresh_button = ttk.Button(prices_tab, text="Refresh", command=self.populate_prices)
        refresh_button.pack(pady=10)

        # Initially populate the treeview
        self.populate_prices()

   
    

    def populate_prices(self):
        # Clear existing data
        for i in self.prices_tree.get_children():
            self.prices_tree.delete(i)

        # Fetch data from the database
        cursor = self.db_instructors.cursor()
        cursor.execute("SELECT NAME, SPECIALIZATION, MODE, EXPERIENCE, CHARGES FROM INSTRUCTORS")
        rows = cursor.fetchall()
        count = 0  # Counter to keep track of rows for coloring
        for row in rows:
            # Insert data into the Treeview, applying color tags based on row index
            if count % 2 == 0:
                self.prices_tree.insert('', 'end', values=row, tags=('evenrow',))
            else:
                self.prices_tree.insert('', 'end', values=row, tags=('oddrow',))
            count += 1
        cursor.close()
    def create_about_ui(self, about_tab):
        # Layout setup: horizontal split
        left_frame = ttk.Frame(about_tab, padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right_frame = ttk.Frame(about_tab, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Text description with bullet points
        about_text = tk.Text(right_frame, wrap=tk.WORD, height=10)
        about_text.pack(expand=True, fill=tk.BOTH)
        about_text.tag_configure('title', font=('Arial', 14, 'bold'), foreground='#3b3b3b')
        about_text.tag_configure('header', font=('Arial', 13, 'bold'), foreground='#555555')
        about_text.tag_configure('list', font=('Arial', 12), lmargin1=20, lmargin2=20, spacing3=10)

        #about_text.insert(tk.END, "Welcome to Pass IT Driving School!\n", 'title')
        about_text.insert(tk.END, "Here are the courses we offer:\n", 'header')
        courses = [
            "Introductory Course - Ideal for beginners.",
            "Standard Course - Covers more complex driving conditions.",
            "Pass Plus - For those who have passed their driving test.",
            "Driving Test Preparation - Focused sessions to prepare for the test."
        ]
        for course in courses:
            about_text.insert(tk.END, f"• {course}\n", 'list')

        about_text.insert(tk.END, "\nBooking Lessons and Tests:\n", 'header')
        about_text.insert(tk.END, "• Students can book lessons directly through their instructors or by calling the driving school office.\n", 'list')
        about_text.insert(tk.END, "• Lesson durations are flexible, typically ranging from one to two hours, with options for longer sessions.\n", 'list')
        about_text.insert(tk.END, "• We facilitate both practical and theory test arrangements, ensuring a seamless experience for our students.\n", 'list')
        about_text.insert(tk.END, "• Successful candidates can advance to our Pass Plus course, enhancing their driving skills further.\n", 'list')
        about_text.config(state=tk.DISABLED)  # Make the text widget read-only



        # Image carousel setup
        self.image_label = ttk.Label(left_frame)
        self.image_label.pack(fill=tk.BOTH, expand=True)

        # Load images
        self.images = self.load_images('img')
        self.image_cycle = itertools.cycle(self.images)
        self.update_image()  # Start the image carousel

    def load_images(self, folder):
        image_files = [get_path(os.path.join(folder, file)) for file in os.listdir(get_path(folder)) if file.endswith(('png', 'jpg', 'jpeg'))]
        return [ImageTk.PhotoImage(Image.open(file).resize((300, 300), Image.Resampling.LANCZOS)) for file in image_files]



    def update_image(self):
        current_image = next(self.image_cycle)
        self.image_label.configure(image=current_image)
        self.image_label.image = current_image  # keep a reference!
        self.after(3000, self.update_image)  # change image every 3000 milliseconds
def set_default_font(root):
    default_font = tkFont.nametofont("TkDefaultFont")
    default_font.configure(family="Helvetica", size=12)
    root.option_add("*Font", default_font)


if __name__ == "__main__":
    
    app = PassITApp()
    set_default_font(app)
    app.mainloop()